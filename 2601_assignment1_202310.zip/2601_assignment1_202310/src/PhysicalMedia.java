
public abstract class PhysicalMedia extends MusicMedia {
	
	public PhysicalMedia() {}
	
	public PhysicalMedia(String sku, String title, String artist, int year) {
		
		super(sku, title, artist, year);
	}

}
