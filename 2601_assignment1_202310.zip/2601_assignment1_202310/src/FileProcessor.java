
public interface FileProcessor {
	
	void save(String filePath);
	void delete(String filePath);

}
